/**
 * Gemini AI Service using direct REST API / @google/genai SDK for HTP child art psychology analysis.
 * Uses gemini-3.5-flash-lite and Firebase RTDB labels.
 * Always returns actual dynamic Gemini analysis.
 */
import { RuleInsights } from '../types';

export async function analyzeDrawingWithGemini(
  imageBase64: string,
  rules: RuleInsights
): Promise<string> {
  const apiKey = (import.meta as any).env?.VITE_GEMINI_API_KEY || (process as any).env?.GEMINI_API_KEY || '';

  if (!apiKey) {
    throw new Error(
      "제미나이 API 키가 설정되지 않았습니다. AI Studio의 [Secrets] 패널에서 'GEMINI_API_KEY'를 등록해주세요."
    );
  }

  const htpLabels = `
  [HTP 클래스별 라벨 구성 (Firebase 기준 분석 라벨)]
  - 집: 집전체, 지붕, 집벽, 문, 창문, 굴뚝, 연기, 울타리, 길, 연못, 산, 나무꽃, 잔디, 태양
  - 나무: 나무전체, 기둥, 수관, 가지, 뿌리, 나뭇잎, 꽃, 열매, 그네, 새, 다람쥐, 구름, 달, 별
  - 사람: 사람전체, 머리, 얼굴, 눈, 코, 입, 귀, 머리카락, 목, 상체, 팔, 손, 다리, 발
  `;

  const systemInstructionText = 
    "당신은 아동 미술 심리 치료 전문가입니다. 첨부된 '실제 캔버스 이미지'와 보조로 제공된 파이어베이스 텍스트 데이터를 분석합니다.\n" +
    "[매우 엄격한 분석 규칙 - 반드시 지킬 것]\n" +
    "1. 시각적 교차 검증: 파이어베이스 텍스트 데이터에 집, 나무, 사람이 있다고 적혀있더라도, **실제 첨부된 그림 이미지에 해당 형태가 없다면 텍스트 데이터를 100% 무시**하세요.\n" +
    "2. 없는 요소 지어내기 금지: 동그라미 하나, 단순한 선, 낙서 등 HTP와 무관한 그림일 경우, 억지로 의미를 부여하지 마세요. 이 경우 다른 분석은 모두 생략하고 **'캔버스에 집, 나무, 사람의 형태가 뚜렷하지 않아 심리 분석을 진행하기 어려워요. 다음에 다시 한번 예쁘게 그려주면 더 잘 분석해 줄게요!'** 라고만 대답하세요.\n" +
    "3. 아이가 그린 요소(집, 사람, 나무 중 이미지에 실제로 존재하는 것)에 대해서만 심층 해석을 진행하세요.\n" +
    "4. 1번 항목 (🎨 아이의 현재 심리 종합 진단): 첨부된 그림을 면밀히 분석하여 아이의 심리 상태, 태도, 에너지 활용 양상을 상세히 진단하세요.\n" +
    "5. 2번 항목 (🔍 HTP 주요 요소별 심층 해석): 사람(Person), 나무(Tree), 집(House) 항목을 각각 분리하여, 실제 이미지에 존재하는 요소에 대해 형태, 크기, 필선을 상세히 분석하세요. 이미지상에 보이지 않는 요소는 현재 관심사 집중 등 부재의 의미를 친절하게 설명하세요.\n" +
    "6. 3번 항목 (💡 부모님을 위한 맞춤형 조언): 아이의 그림 특성에 꼭 맞는 실천적 조언을 제시하세요.\n" +
    "7. HTML 태그(<h3 style='color:#9333ea; font-weight:bold;'>, <p>, <strong>, <ul>, <li>, <br>)를 사용하여 가독성 높게 작성하세요.";

  const userPromptText = `[실시간 캔버스 드로잉 데이터 1차 진단 결과]\n` +
    `- 요약수치: ${rules.summary || '특이사항 없음'}\n` +
    `- 룰(Rule) 적용 도출 결론:\n - ${(rules.appliedRules || []).join('\n - ')}\n\n` +
    `${htpLabels}\n` +
    `다음 항목을 짧고 명확하며 구체적으로 분석해 주세요:\n` +
    `1. 🎨 아이의 현재 심리 종합 진단\n` +
    `2. 🔍 HTP 주요 요소별 심층 해석 (실제 이미지에 존재하는 요소 중심)\n` +
    `3. 💡 부모님을 위한 맞춤형 조언`;

  const cleanBase64 = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
  const mime = imageBase64.includes('image/jpeg') ? 'image/jpeg' : 'image/png';

  const parts: any[] = [{ text: userPromptText }];
  if (cleanBase64) {
    parts.push({
      inlineData: {
        mimeType: mime,
        data: cleanBase64,
      },
    });
  }

  const requestBody = {
    contents: [{ role: 'user', parts: parts }],
    systemInstruction: { parts: [{ text: systemInstructionText }] },
  };

  const modelId = 'gemini-3.5-flash-lite';
  let apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent?key=${apiKey}`;

  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestBody),
  };

  let response: any;
  let responseCode = 0;
  let responseText = '';
  const maxRetries = 3;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    response = await fetch(apiUrl, options);
    responseCode = response.status;
    responseText = await response.text();

    if (responseCode === 200) break;
    if (responseCode === 429 && attempt < maxRetries) {
      await new Promise((res) => setTimeout(res, 2000 * attempt));
    } else if (responseCode === 404 && attempt === 1) {
      apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
    } else {
      throw new Error(`Gemini API 오류 (${responseCode}): ${responseText}`);
    }
  }

  const jsonResult = JSON.parse(responseText);

  if (
    jsonResult.candidates &&
    jsonResult.candidates.length > 0 &&
    jsonResult.candidates[0].content &&
    jsonResult.candidates[0].content.parts &&
    jsonResult.candidates[0].content.parts.length > 0
  ) {
    return jsonResult.candidates[0].content.parts[0].text;
  } else if (jsonResult.error) {
    throw new Error(`Gemini API 오류: ${jsonResult.error.message || responseText}`);
  } else {
    throw new Error('Gemini API에서 올바른 답변 텍스트를 생성하지 못했습니다.');
  }
}
